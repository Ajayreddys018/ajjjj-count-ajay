import Image from 'next/image';
import Link from 'next/link';
import Header from '@/components/header';
import Footer from '@/components/footer';
import { Button } from '@/components/ui/button';

export default function Home() {
  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="container py-16 md:py-24">
          <div className="flex flex-col items-center">
            <Image
              src="/images/landing.png"
              alt="Zerodha Platform"
              width={520}
              height={300}
              className="mb-8"
              priority
            />
            <h1 className="text-3xl md:text-4xl font-medium text-center mb-4">
              Invest in everything
            </h1>
            <p className="text-center text-muted-foreground mb-8 max-w-lg">
              Online platform to invest in stocks, derivatives, mutual funds, ETFs, bonds, and more.
            </p>
            <Link href="/open-account">
              <Button className="rounded-md bg-blue-600 hover:bg-blue-700">
                Sign up for free
              </Button>
            </Link>
          </div>
        </section>

        {/* Trust Section */}
        <section className="container py-16">
          <h2 className="text-2xl font-medium mb-12">Trust with confidence</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <h3 className="text-base font-medium mb-2">Customer-first always</h3>
              <p className="text-muted-foreground text-sm">
                That's why 1.5+ crore customers trust Zerodha with ₹4.5+ lakh crores of equity investments and contribute to 15% of daily retail exchange volumes in India.
              </p>
            </div>
            <div>
              <h3 className="text-base font-medium mb-2">No spam or gimmicks</h3>
              <p className="text-muted-foreground text-sm">
                No gimmicks, spam, "gamification", or annoying push notifications. High quality apps that you use at your pace, the way you like.
              </p>
            </div>
            <div>
              <h3 className="text-base font-medium mb-2">The Zerodha universe</h3>
              <p className="text-muted-foreground text-sm">
                Not just an app, but a whole ecosystem. Our investments in 30+ fintech startups offer you tailored services specific to your needs.
              </p>
            </div>
            <div>
              <h3 className="text-base font-medium mb-2">Do better with money</h3>
              <p className="text-muted-foreground text-sm">
                With initiatives like Nudge and Kill Switch, we don't just facilitate transactions, but actively help you do better with your money.
              </p>
            </div>
          </div>
          <div className="mt-16 flex justify-center md:justify-start">
            <div className="flex gap-6">
              <Link href="/products">
                <Button variant="outline" className="rounded-md">
                  Explore our products
                </Button>
              </Link>
              <Link href="https://kite-demo.zerodha.com">
                <Button variant="outline" className="rounded-md">
                  Try Kite demo
                </Button>
              </Link>
            </div>
          </div>
          <div className="mt-16">
            <Image
              src="/images/press-logos.png"
              alt="Featured in press"
              width={500}
              height={40}
              className="mx-auto md:mx-0"
            />
          </div>
        </section>

        {/* Pricing Section */}
        <section className="container py-16">
          <h2 className="text-2xl font-medium mb-12">Unbeatable pricing</h2>
          <p className="mb-8 text-muted-foreground max-w-xl">
            We pioneered the concept of discount broking and price transparency in India. Flat fees and no hidden charges.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-8">
            <div className="flex flex-col items-center">
              <Image
                src="/images/pricing-eq.svg"
                alt="Free equity delivery"
                width={100}
                height={100}
                className="mb-4"
              />
              <h3 className="text-lg font-medium mb-2">Free equity delivery</h3>
              <p className="text-sm text-center text-muted-foreground">
                All equity delivery investments (NSE, BSE), are absolutely free — 0 brokerage.
              </p>
            </div>
            <div className="flex flex-col items-center">
              <Image
                src="/images/other-trades.svg"
                alt="Intraday and F&O trades"
                width={100}
                height={100}
                className="mb-4"
              />
              <h3 className="text-lg font-medium mb-2">Intraday and F&O trades</h3>
              <p className="text-sm text-center text-muted-foreground">
                Flat ₹20 or 0.03% (whichever is lower) per executed order on intraday trades across equity, currency, and commodity trades. Flat ₹20 on all option trades.
              </p>
            </div>
            <div className="flex flex-col items-center">
              <Image
                src="/images/pricing-eq.svg"
                alt="Free direct MF"
                width={100}
                height={100}
                className="mb-4"
              />
              <h3 className="text-lg font-medium mb-2">Free direct MF</h3>
              <p className="text-sm text-center text-muted-foreground">
                All direct mutual fund investments are absolutely free — 0 commissions & DP charges.
              </p>
            </div>
          </div>
          <div className="flex justify-center md:justify-start mt-8">
            <Link href="/charges">
              <Button variant="outline" className="rounded-md">
                See pricing
              </Button>
            </Link>
          </div>
        </section>

        {/* Education Section */}
        <section className="container py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <Image
                src="/images/index-education.svg"
                alt="Varsity by Zerodha"
                width={300}
                height={300}
              />
            </div>
            <div>
              <h2 className="text-2xl font-medium mb-6">Free and open market education</h2>
              <p className="mb-6 text-muted-foreground">
                Varsity, the largest online stock market education book in the world covering everything from the basics to advanced trading.
              </p>
              <Link href="https://zerodha.com/varsity">
                <Button variant="outline" className="rounded-md mb-8">
                  Varsity
                </Button>
              </Link>
              <p className="mb-6 text-muted-foreground">
                TradingQ&A, the most active trading and investment community in India for all your market related queries.
              </p>
              <Link href="https://tradingqna.com">
                <Button variant="outline" className="rounded-md">
                  TradingQ&A
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Open Account Section */}
        <section className="container py-16 text-center">
          <h2 className="text-2xl font-medium mb-4">Open a Zerodha account</h2>
          <p className="mb-8 text-muted-foreground max-w-md mx-auto">
            Modern platforms and apps, ₹0 investments, and flat ₹20 intraday and F&O trades.
          </p>
          <Link href="/open-account">
            <Button className="rounded-md bg-blue-600 hover:bg-blue-700">
              Sign up for free
            </Button>
          </Link>
        </section>
      </main>
      <Footer />
    </>
  );
}
