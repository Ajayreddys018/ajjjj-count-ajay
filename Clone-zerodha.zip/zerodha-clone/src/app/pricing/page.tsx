import Image from 'next/image';
import Link from 'next/link';
import Header from '@/components/header';
import Footer from '@/components/footer';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";

export default function PricingPage() {
  return (
    <>
      <Header />
      <main>
        <section className="container py-16">
          <h1 className="text-3xl font-medium text-center mb-2">Charges</h1>
          <p className="text-center text-muted-foreground mb-16">
            List of all charges and taxes
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-8">
            <div className="flex flex-col items-center">
              <Image
                src="/images/pricing-eq.svg"
                alt="Free equity delivery"
                width={100}
                height={100}
                className="mb-4"
              />
              <h3 className="text-lg font-medium mb-2">Free equity delivery</h3>
              <p className="text-sm text-center text-muted-foreground">
                All equity delivery investments (NSE, BSE), are absolutely free — 0 brokerage.
              </p>
            </div>
            <div className="flex flex-col items-center">
              <Image
                src="/images/other-trades.svg"
                alt="Intraday and F&O trades"
                width={100}
                height={100}
                className="mb-4"
              />
              <h3 className="text-lg font-medium mb-2">Intraday and F&O trades</h3>
              <p className="text-sm text-center text-muted-foreground">
                Flat ₹20 or 0.03% (whichever is lower) per executed order on intraday trades across equity, currency, and commodity trades. Flat ₹20 on all option trades.
              </p>
            </div>
            <div className="flex flex-col items-center">
              <Image
                src="/images/pricing-eq.svg"
                alt="Free direct MF"
                width={100}
                height={100}
                className="mb-4"
              />
              <h3 className="text-lg font-medium mb-2">Free direct MF</h3>
              <p className="text-sm text-center text-muted-foreground">
                All direct mutual fund investments are absolutely free — 0 commissions & DP charges.
              </p>
            </div>
          </div>

          <div className="my-16">
            <Tabs defaultValue="equity" className="w-full">
              <TabsList className="w-full flex justify-start mb-8 overflow-x-auto">
                <TabsTrigger value="equity" className="px-6">Equity</TabsTrigger>
                <TabsTrigger value="fo" className="px-6">F&O</TabsTrigger>
                <TabsTrigger value="currency" className="px-6">Currency</TabsTrigger>
                <TabsTrigger value="commodity" className="px-6">Commodity</TabsTrigger>
              </TabsList>

              <TabsContent value="equity">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead></TableHead>
                      <TableHead>Equity delivery</TableHead>
                      <TableHead>Equity intraday</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">Brokerage</TableCell>
                      <TableCell>Zero Brokerage</TableCell>
                      <TableCell>0.03% or Rs. 20/executed order whichever is lower</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">STT/CTT</TableCell>
                      <TableCell>0.1% on buy & sell</TableCell>
                      <TableCell>0.025% on the sell side</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Transaction charges</TableCell>
                      <TableCell>NSE: 0.00297%<br />BSE: 0.00375%</TableCell>
                      <TableCell>NSE: 0.00297%<br />BSE: 0.00375%</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">GST</TableCell>
                      <TableCell>18% on (brokerage + SEBI charges + transaction charges)</TableCell>
                      <TableCell>18% on (brokerage + SEBI charges + transaction charges)</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">SEBI charges</TableCell>
                      <TableCell>₹10 / crore</TableCell>
                      <TableCell>₹10 / crore</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Stamp charges</TableCell>
                      <TableCell>0.015% or ₹1500 / crore on buy side</TableCell>
                      <TableCell>0.003% or ₹300 / crore on buy side</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TabsContent>

              <TabsContent value="fo">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead></TableHead>
                      <TableHead>F&O - Futures</TableHead>
                      <TableHead>F&O - Options</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">Brokerage</TableCell>
                      <TableCell>0.03% or Rs. 20/executed order whichever is lower</TableCell>
                      <TableCell>Flat Rs. 20 per executed order</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">STT/CTT</TableCell>
                      <TableCell>0.02% on the sell side</TableCell>
                      <TableCell>
                        <ul className="list-disc list-inside">
                          <li>0.0125% of the intrinsic value on options that are bought and exercised</li>
                          <li>0.1% on sell side (on premium)</li>
                        </ul>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Transaction charges</TableCell>
                      <TableCell>NSE: 0.00173%<br />BSE: 0</TableCell>
                      <TableCell>NSE: 0.03503% (on premium)<br />BSE: 0.0325% (on premium)</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">GST</TableCell>
                      <TableCell>18% on (brokerage + SEBI charges + transaction charges)</TableCell>
                      <TableCell>18% on (brokerage + SEBI charges + transaction charges)</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">SEBI charges</TableCell>
                      <TableCell>₹10 / crore</TableCell>
                      <TableCell>₹10 / crore</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Stamp charges</TableCell>
                      <TableCell>0.002% or ₹200 / crore on buy side</TableCell>
                      <TableCell>0.003% or ₹300 / crore on buy side</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TabsContent>

              <TabsContent value="currency">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead></TableHead>
                      <TableHead>Currency futures</TableHead>
                      <TableHead>Currency options</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">Brokerage</TableCell>
                      <TableCell>0.03% or ₹20/executed order whichever is lower</TableCell>
                      <TableCell>₹20/executed order</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">STT/CTT</TableCell>
                      <TableCell>No STT</TableCell>
                      <TableCell>No STT</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Transaction charges</TableCell>
                      <TableCell>NSE: 0.00035%<br />BSE: 0.00045%</TableCell>
                      <TableCell>NSE: 0.0311%<br />BSE: 0.001%</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">GST</TableCell>
                      <TableCell>18% on (brokerage + SEBI charges + transaction charges)</TableCell>
                      <TableCell>18% on (brokerage + SEBI charges + transaction charges)</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">SEBI charges</TableCell>
                      <TableCell>₹10 / crore</TableCell>
                      <TableCell>₹10 / crore</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Stamp charges</TableCell>
                      <TableCell>0.0001% or ₹10 / crore on buy side</TableCell>
                      <TableCell>0.0001% or ₹10 / crore on buy side</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TabsContent>

              <TabsContent value="commodity">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead></TableHead>
                      <TableHead>Commodity futures</TableHead>
                      <TableHead>Commodity options</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">Brokerage</TableCell>
                      <TableCell>0.03% or Rs. 20/executed order whichever is lower</TableCell>
                      <TableCell>₹20/executed order</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">STT/CTT</TableCell>
                      <TableCell>0.01% on sell side (Non-Agri)</TableCell>
                      <TableCell>0.05% on sell side</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Transaction charges</TableCell>
                      <TableCell>MCX: 0.0021%<br />NSE: 0.0001%</TableCell>
                      <TableCell>MCX: 0.0418%<br />NSE: 0.001%</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">GST</TableCell>
                      <TableCell>18% on (brokerage + SEBI charges + transaction charges)</TableCell>
                      <TableCell>18% on (brokerage + SEBI charges + transaction charges)</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">SEBI charges</TableCell>
                      <TableCell>Agri: ₹1 / crore<br />Non-agri: ₹10 / crore</TableCell>
                      <TableCell>₹10 / crore</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Stamp charges</TableCell>
                      <TableCell>0.002% or ₹200 / crore on buy side</TableCell>
                      <TableCell>0.003% or ₹300 / crore on buy side</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TabsContent>
            </Tabs>

            <div className="mt-8 text-center">
              <Link href="/brokerage-calculator">
                <Button variant="outline" className="rounded-md">
                  Calculate your costs upfront using our brokerage calculator
                </Button>
              </Link>
            </div>
          </div>

          <div className="mt-16">
            <h2 className="text-2xl font-medium mb-8">Charges explained</h2>

            <div className="space-y-8">
              <div>
                <h3 className="text-lg font-medium mb-2">Securities/Commodities transaction tax</h3>
                <p className="text-muted-foreground">
                  Tax by the government when transacting on the exchanges. Charged as above on both buy and sell sides when trading equity delivery. Charged only on selling side when trading intraday or on F&O.
                </p>
                <p className="text-muted-foreground mt-2">
                  When trading at Zerodha, STT/CTT can be a lot more than the brokerage we charge. Important to keep a tab.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">Transaction/Turnover Charges</h3>
                <p className="text-muted-foreground">
                  Charged by exchanges (NSE, BSE, MCX) on the value of your transactions.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">GST</h3>
                <p className="text-muted-foreground">
                  Tax levied by the government on the services rendered. 18% of (brokerage + SEBI charges + transaction charges)
                </p>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">SEBI Charges</h3>
                <p className="text-muted-foreground">
                  Charged at ₹10 per crore + GST by Securities and Exchange Board of India for regulating the markets.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">DP (Depository participant) charges</h3>
                <p className="text-muted-foreground">
                  ₹15.34 per scrip (₹3.5 CDSL fee + ₹9.5 Zerodha fee + ₹2.34 GST) is charged on the trading account ledger when stocks are sold, irrespective of quantity.
                </p>
                <p className="text-muted-foreground mt-2">
                  Female demat account holders (as first holder) will enjoy a discount of ₹0.25 per transaction on the CDSL fee.
                </p>
                <p className="text-muted-foreground mt-2">
                  Debit transactions of mutual funds & bonds get an additional discount of ₹0.25 on the CDSL fee.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-16">
            <h2 className="text-2xl font-medium mb-8">Charges for account opening</h2>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type of account</TableHead>
                  <TableHead>Charges</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>Online account</TableCell>
                  <TableCell className="text-green-600">free</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Offline account</TableCell>
                  <TableCell className="text-green-600">free</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>NRI account (offline only)</TableCell>
                  <TableCell>₹500</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Partnership, LLP, HUF, or Corporate accounts (offline only)</TableCell>
                  <TableCell>₹500</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          <div className="mt-16">
            <h2 className="text-2xl font-medium mb-8">Charges for optional value added services</h2>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Service</TableHead>
                  <TableHead>Billing Frequency</TableHead>
                  <TableHead>Charges</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>Tickertape</TableCell>
                  <TableCell>Monthly / Annual</TableCell>
                  <TableCell>Free: 0 | Pro: 249/2399</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Smallcase</TableCell>
                  <TableCell>Per transaction</TableCell>
                  <TableCell>Buy & Invest More: 100 | SIP: 10</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Kite Connect</TableCell>
                  <TableCell>Monthly</TableCell>
                  <TableCell>Connect: 2000 | Historical: 2000</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
