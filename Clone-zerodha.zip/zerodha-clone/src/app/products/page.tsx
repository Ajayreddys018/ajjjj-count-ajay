import Image from 'next/image';
import Link from 'next/link';
import Header from '@/components/header';
import Footer from '@/components/footer';
import { Button } from '@/components/ui/button';

const products = [
  {
    id: 'kite',
    name: 'Kite',
    description: 'Our ultra-fast flagship trading platform with streaming market data, advanced charts, an elegant UI, and more. Enjoy the Kite experience seamlessly on your Android and iOS devices.',
    image: '/images/products-kite.png',
    logo: '/images/kite-logo.svg',
    demo: 'https://kite-demo.zerodha.com',
    learnMore: '/products/kite',
    hasAppLinks: true,
    reversed: false,
  },
  {
    id: 'console',
    name: 'Console',
    description: 'The central dashboard for your Zerodha account. Gain insights into your trades and investments with in-depth reports and visualisations.',
    image: '/images/products-console.png',
    logo: '/images/console-logo.svg',
    learnMore: '/products/console',
    hasAppLinks: false,
    reversed: true,
  },
  {
    id: 'coin',
    name: 'Coin',
    description: 'Buy direct mutual funds online, commission-free, delivered directly to your Demat account. Enjoy the investment experience on your Android and iOS devices.',
    image: '/images/products-coin.png',
    logo: '/images/coin-logo.svg',
    learnMore: 'https://coin.zerodha.com',
    hasAppLinks: true,
    reversed: false,
  },
  {
    id: 'kite-connect',
    name: 'Kite Connect API',
    description: 'Build powerful trading platforms and experiences with our super simple HTTP/JSON APIs. If you are a startup, build your investment app and showcase it to our clientbase.',
    image: '/images/products-kiteconnect.png',
    logo: '/images/kite-connect-logo.svg',
    learnMore: 'https://kite.trade',
    hasAppLinks: false,
    reversed: true,
  },
];

const partnerPlatforms = [
  {
    name: 'Zerodha Fund House',
    description: 'Our asset management venture that is creating simple and transparent index funds to help you save for your goals.',
    url: 'https://www.zerodhafundhouse.com/',
  },
  {
    name: 'Streak',
    description: 'Systematic trading platform that allows you to create and backtest strategies without coding.',
    url: 'https://streak.tech',
  },
  {
    name: 'Sensibull',
    description: 'Options trading platform that lets you create strategies, analyze positions, and examine data points like open interest, FII/DII, and more.',
    url: 'https://sensibull.com',
  },
  {
    name: 'Smallcase',
    description: 'Thematic investing platform that helps you invest in diversified baskets of stocks on ETFs.',
    url: 'https://smallcase.zerodha.com',
  },
  {
    name: 'Tijori Finance',
    description: 'Investment research platform that offers detailed insights on stocks, sectors, supply chains, and more.',
    url: 'https://www.tijorifinance.com/',
  },
  {
    name: 'Ditto',
    description: 'Personalized advice on life and health insurance. No spam and no mis-selling.',
    url: 'https://joinditto.in/',
  },
];

export default function ProductsPage() {
  return (
    <>
      <Header />
      <main>
        <section className="container py-16">
          <h1 className="text-3xl font-medium text-center mb-2">Zerodha Products</h1>
          <p className="text-center text-muted-foreground mb-8">
            Sleek, modern, and intuitive trading platforms
          </p>
          <p className="text-center mb-16">
            <Link href="/investments" className="text-primary hover:underline">
              Check out our investment offerings
            </Link>
          </p>

          {/* Products */}
          {products.map((product) => (
            <div
              key={product.id}
              className={`grid grid-cols-1 md:grid-cols-2 gap-16 items-center py-16 ${
                product.reversed ? 'md:flex-row-reverse' : ''
              }`}
            >
              <div className={product.reversed ? 'order-1 md:order-2' : ''}>
                <Image
                  src={product.image}
                  alt={product.name}
                  width={500}
                  height={400}
                  className="rounded-lg shadow-md"
                />
              </div>
              <div className={product.reversed ? 'order-2 md:order-1' : ''}>
                <h2 className="text-2xl font-medium mb-4">{product.name}</h2>
                <p className="text-muted-foreground mb-6">
                  {product.description}
                </p>
                <div className="flex gap-4 flex-wrap">
                  {product.demo && (
                    <Link href={product.demo}>
                      <Button variant="outline" className="rounded-md mb-4">
                        Try demo
                      </Button>
                    </Link>
                  )}
                  <Link href={product.learnMore}>
                    <Button variant="outline" className="rounded-md mb-4">
                      Learn more
                    </Button>
                  </Link>
                </div>
                {product.hasAppLinks && (
                  <div className="flex gap-4 mt-2">
                    <Link href="https://play.google.com/store/apps/details?id=com.zerodha.kite3" target="_blank" rel="noopener noreferrer">
                      <Image
                        src="/images/google-play-badge.svg"
                        alt="Get on Google Play"
                        width={135}
                        height={40}
                      />
                    </Link>
                    <Link href="https://apps.apple.com/in/app/kite-zerodha/id1449453802" target="_blank" rel="noopener noreferrer">
                      <Image
                        src="/images/app-store-badge.svg"
                        alt="Download on the App Store"
                        width={135}
                        height={40}
                      />
                    </Link>
                  </div>
                )}
              </div>
            </div>
          ))}

          <div className="py-8 text-center">
            <p className="text-muted-foreground">
              Want to know more about our technology stack? Check out the{' '}
              <Link href="https://zerodha.tech/" className="text-primary hover:underline">
                Zerodha.tech
              </Link>{' '}
              blog.
            </p>
          </div>
        </section>

        {/* Partner Platforms */}
        <section className="container py-16">
          <h2 className="text-2xl font-medium text-center mb-4">The Zerodha Universe</h2>
          <p className="text-center text-muted-foreground mb-16">
            Extend your trading and investment experience even further with our partner platforms
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {partnerPlatforms.map((platform) => (
              <div key={platform.name} className="border rounded-lg p-6 hover:shadow-md transition-shadow">
                <h3 className="text-lg font-medium mb-3">{platform.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {platform.description}
                </p>
                <Link
                  href={platform.url}
                  className="text-primary text-sm hover:underline"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Visit {platform.name}
                </Link>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <Link href="/open-account">
              <Button className="rounded-md bg-blue-600 hover:bg-blue-700">
                Sign up for free
              </Button>
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
