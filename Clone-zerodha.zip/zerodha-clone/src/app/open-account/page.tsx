import Image from 'next/image';
import Link from 'next/link';
import Header from '@/components/header';
import Footer from '@/components/footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

export default function OpenAccountPage() {
  return (
    <>
      <Header />
      <main>
        <section className="container py-16">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-3xl font-medium text-center mb-4">Open a Zerodha Account</h1>
            <p className="text-center text-muted-foreground mb-12">
              Open a Zerodha brokerage account to invest in stocks, bonds, mutual funds, and more.
            </p>

            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="text-xl">Account Opening Process</CardTitle>
                <CardDescription>
                  Complete the following steps to open your Zerodha account.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6">
                  <div className="flex items-start gap-4">
                    <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white text-sm font-medium shrink-0">1</div>
                    <div>
                      <h3 className="text-base font-medium">Sign up with your email</h3>
                      <p className="text-sm text-muted-foreground">
                        Enter your email address to create your Zerodha account.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white text-sm font-medium shrink-0">2</div>
                    <div>
                      <h3 className="text-base font-medium">Complete your KYC</h3>
                      <p className="text-sm text-muted-foreground">
                        Submit your KYC documents online. Requires Aadhaar and PAN card.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white text-sm font-medium shrink-0">3</div>
                    <div>
                      <h3 className="text-base font-medium">Sign the digital agreement</h3>
                      <p className="text-sm text-muted-foreground">
                        Sign the digital agreement using Aadhaar OTP.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white text-sm font-medium shrink-0">4</div>
                    <div>
                      <h3 className="text-base font-medium">Make an initial fund transfer</h3>
                      <p className="text-sm text-muted-foreground">
                        Transfer funds to your new Zerodha account to start investing.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Enter your details</CardTitle>
                <CardDescription>
                  Fill in your information to start the account opening process.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Full Name
                      </label>
                      <input
                        id="name"
                        type="text"
                        className="w-full p-2 border rounded-md"
                        placeholder="Your full name"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email
                      </label>
                      <input
                        id="email"
                        type="email"
                        className="w-full p-2 border rounded-md"
                        placeholder="Your email address"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="mobile" className="text-sm font-medium">
                        Mobile Number
                      </label>
                      <input
                        id="mobile"
                        type="tel"
                        className="w-full p-2 border rounded-md"
                        placeholder="10-digit mobile number"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="pan" className="text-sm font-medium">
                        PAN
                      </label>
                      <input
                        id="pan"
                        type="text"
                        className="w-full p-2 border rounded-md"
                        placeholder="Your PAN number"
                      />
                    </div>
                  </div>

                  <div className="flex items-start space-x-2">
                    <input
                      id="terms"
                      type="checkbox"
                      className="mt-1"
                    />
                    <label htmlFor="terms" className="text-sm text-muted-foreground">
                      I agree to the <Link href="/terms-and-conditions" className="text-primary hover:underline">Terms and Conditions</Link> and <Link href="/privacy-policy" className="text-primary hover:underline">Privacy Policy</Link>
                    </label>
                  </div>
                </form>
              </CardContent>
              <CardFooter className="flex justify-center">
                <Button className="rounded-md bg-blue-600 hover:bg-blue-700 w-full md:w-auto px-8">
                  Continue
                </Button>
              </CardFooter>
            </Card>

            <div className="mt-12 text-center text-sm text-muted-foreground">
              <p>For any assistance, call us at <span className="font-medium">+91-80-40402020</span></p>
              <p className="mt-1">or email us at <a href="mailto:support@zerodha.com" className="text-primary hover:underline">support@zerodha.com</a></p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
