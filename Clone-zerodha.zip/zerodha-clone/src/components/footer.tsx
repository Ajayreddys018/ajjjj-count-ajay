import Link from 'next/link';
import Image from 'next/image';

const companyLinks = [
  { name: 'About', href: '/about' },
  { name: 'Products', href: '/products' },
  { name: 'Pricing', href: '/pricing' },
  { name: 'Referral programme', href: '/refer' },
  { name: 'Careers', href: 'https://careers.zerodha.com' },
  { name: 'Zerodha.tech', href: 'https://zerodha.tech' },
  { name: 'Open source', href: '/open-source' },
  { name: 'Press & media', href: '/media' },
  { name: 'Zerodha Cares (CSR)', href: '/cares' },
];

const supportLinks = [
  { name: 'Contact us', href: '/contact' },
  { name: 'Support portal', href: 'https://support.zerodha.com' },
  { name: 'Z-Connect blog', href: '/z-connect' },
  { name: 'List of charges', href: '/charges' },
  { name: 'Downloads & resources', href: '/resources' },
  { name: 'Videos', href: '/videos' },
  { name: 'Market overview', href: 'https://stocks.zerodha.com' },
  { name: 'How to file a complaint?', href: 'https://support.zerodha.com/category/your-zerodha-account/your-profile/ticket-creation/articles/how-do-i-create-a-ticket-at-zerodha' },
  { name: 'Status of your complaints', href: 'https://support.zerodha.com/category/your-zerodha-account/your-profile/ticket-creation/articles/track-complaints-or-tickets' },
];

const accountLinks = [
  { name: 'Open an account', href: '/open-account' },
  { name: 'Fund transfer', href: '/fund-transfer' },
];

const exchangeLinks = [
  { name: 'NSE', href: 'https://nseindia.com' },
  { name: 'BSE', href: 'https://www.bseindia.com/' },
  { name: 'MCX', href: 'https://www.mcxindia.com/' },
];

const legalLinks = [
  { name: 'Terms & conditions', href: '/terms-and-conditions' },
  { name: 'Policies & procedures', href: '/policies-and-procedures' },
  { name: 'Privacy policy', href: '/privacy-policy' },
  { name: 'Disclosure', href: '/disclosure' },
  { name: "For investor's attention", href: '/investor-attention' },
  { name: 'Investor charter', href: '/tos/investor-charter' },
];

const socialLinks = [
  { name: 'Twitter', href: 'https://twitter.com/zerodhaonline', icon: '/images/x-twitter.svg' },
  { name: 'Facebook', href: 'https://facebook.com/zerodha.social', icon: '' },
  { name: 'Instagram', href: 'https://instagram.com/zerodhaonline/', icon: '' },
  { name: 'LinkedIn', href: 'https://linkedin.com/company/zerodha', icon: '' },
  { name: 'YouTube', href: 'https://www.youtube.com/@zerodhaonline', icon: '/images/youtube.svg' },
  { name: 'WhatsApp', href: 'https://whatsapp.com/channel/0029Va8tzF0EquiIIb9j791g', icon: '/images/whatsapp.svg' },
  { name: 'Telegram', href: 'https://t.me/zerodhain', icon: '' },
];

export default function Footer() {
  return (
    <footer className="w-full bg-white border-t mt-20 py-12">
      <div className="container">
        <div className="mb-8">
          <Link href="/" className="inline-block">
            <Image
              src="/images/logo.svg"
              alt="Zerodha"
              width={120}
              height={18}
              className="h-auto w-[110px]"
            />
          </Link>
          <p className="text-xs text-muted-foreground mt-4">
            © 2010 - 2025, Zerodha Broking Ltd.<br />
            All rights reserved.
          </p>
          <div className="flex space-x-4 mt-4">
            {socialLinks.map((link, index) => (
              <Link
                key={index}
                href={link.href}
                className="text-muted-foreground hover:text-primary transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                {link.icon ? (
                  <Image
                    src={link.icon}
                    alt={link.name}
                    width={20}
                    height={20}
                    className="h-5 w-5"
                  />
                ) : (
                  <span className="text-sm">{link.name.charAt(0)}</span>
                )}
              </Link>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-sm font-medium mb-4">Company</h3>
            <ul className="space-y-2">
              {companyLinks.map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-medium mb-4">Support</h3>
            <ul className="space-y-2">
              {supportLinks.map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-medium mb-4">Account</h3>
            <ul className="space-y-2">
              {accountLinks.map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 text-xs text-muted-foreground">
          <p className="mb-6 leading-relaxed">
            Zerodha Broking Ltd.: Member of NSE, BSE & MCX SEBI Registration no.: INZ000031633 CDSL/NSDL: Depository services through Zerodha Broking Ltd. SEBI Registration no.: IN-DP-431-2019 Commodity Trading through Zerodha Commodities Pvt. Ltd. MCX: 46025; NSE-50001 SEBI Registration no.: INZ000038238 Registered Address: Zerodha Broking Ltd., #153/154, 4th Cross, Dollars Colony, Opp. Clarence Public School, J.P Nagar 4th Phase, Bengaluru - 560078, Karnataka, India. For any complaints pertaining to securities broking please write to <a href="mailto:complaints@zerodha.com" className="text-primary hover:underline">complaints@zerodha.com</a>, for DP related to <a href="mailto:dp@zerodha.com" className="text-primary hover:underline">dp@zerodha.com</a>. Please ensure you carefully read the Risk Disclosure Document as prescribed by SEBI | ICF
          </p>

          <p className="mb-6 leading-relaxed">
            Investments in securities market are subject to market risks; read all the related documents carefully before investing.
          </p>

          <p className="mb-6 leading-relaxed">
            Attention investors: 1) Stock brokers can accept securities as margins from clients only by way of pledge in the depository system w.e.f September 01, 2020. 2) Update your e-mail and phone number with your stock broker / depository participant and receive OTP directly from depository on your e-mail and/or mobile number to create pledge. 3) Check your securities / MF / bonds in the consolidated account statement issued by NSDL/CDSL every month.
          </p>

          <div className="flex flex-wrap gap-4 mt-8">
            {exchangeLinks.map((link, index) => (
              <Link
                key={index}
                href={link.href}
                className="text-xs text-muted-foreground hover:text-primary transition-colors"
              >
                {link.name}
              </Link>
            ))}

            {legalLinks.map((link, index) => (
              <Link
                key={index}
                href={link.href}
                className="text-xs text-muted-foreground hover:text-primary transition-colors"
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
